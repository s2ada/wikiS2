<?php
	$wgUseInstantCommons = true;
